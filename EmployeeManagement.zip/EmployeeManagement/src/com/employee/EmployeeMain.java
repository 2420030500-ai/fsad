package com.employee;

import java.util.*;

public class EmployeeMain {

    static ArrayList<Employee> list = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        // ---- Preloaded Real Employee Data ----
        list.add(new Employee(101, "Dr. Ramya", 65000, "Professor"));
        list.add(new Employee(102, "Anil Kumar", 42000, "Lab Assistant"));
        list.add(new Employee(103, "Kavya Reddy", 78000, "Head of Department"));
        list.add(new Employee(104, "Ramesh Naidu", 55000, "Accountant"));
        list.add(new Employee(105, "Sita Devi", 30000, "Office Staff"));
        // --------------------------------------

        while (true) {
            System.out.println("\n--- Employee Management System ---");
            System.out.println("1. Add Employee");
            System.out.println("2. Show Employees with Salary > 50,000");
            System.out.println("3. Show Average Salary");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    showHighSalary();
                    break;
                case 3:
                    showAverageSalary();
                    break;
                case 4:
                    System.out.println("Thank You!");
                    System.exit(0);
                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }

    static void addEmployee() {
        System.out.print("Enter Employee ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Employee Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Salary: ");
        double salary = sc.nextDouble();
        sc.nextLine();

        System.out.print("Enter Designation: ");
        String des = sc.nextLine();

        list.add(new Employee(id, name, salary, des));
        System.out.println("Employee Added Successfully!");
    }

    static void showHighSalary() {
        System.out.println("\nEmployees with Salary > 50,000:");
        for (Employee e : list) {
            if (e.getSalary() > 50000) {
                System.out.println(e.getEmpId() + " " + e.getEmpName() + " " + e.getSalary() + " " + e.getDesignation());
            }
        }
    }

    static void showAverageSalary() {
        if (list.size() == 0) {
            System.out.println("No employees found!");
            return;
        }
        double total = 0;
        for (Employee e : list) total += e.getSalary();
        System.out.println("Average Salary = " + (total / list.size()));
    }
}
