package com.klu;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.Scanner;

public class APP {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\n--- Student Management System ---");
            System.out.println("1. Insert Student");
            System.out.println("2. View Student (Read)");
            System.out.println("3. Update Student Dept");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: // CREATE
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    System.out.print("Enter Name: ");
                    String name = sc.next();
                    System.out.print("Enter Dept: ");
                    String dept = sc.next();

                    Session s1 = HibernateUtil.getSessionFactory().openSession();
                    Transaction tx1 = s1.beginTransaction();
                    
                    Student std = new Student(id, name, dept);
                    s1.save(std);
                    
                    tx1.commit();
                    s1.close();
                    System.out.println("Student Inserted Successfully!");
                    break;

                case 2: // READ
                    System.out.print("Enter Student ID to view: ");
                    int readId = sc.nextInt();
                    
                    Session s2 = HibernateUtil.getSessionFactory().openSession();
                    Student foundStd = s2.get(Student.class, readId);
                    
                    if (foundStd != null) {
                        System.out.println("Data: " + foundStd.getName() + " | " + foundStd.getDept());
                    } else {
                        System.out.println("Student not found!");
                    }
                    s2.close();
                    break;

                case 3: // UPDATE
                    System.out.print("Enter Student ID to update: ");
                    int upId = sc.nextInt();
                    
                    Session s3 = HibernateUtil.getSessionFactory().openSession();
                    Transaction tx3 = s3.beginTransaction();
                    
                    Student upStd = s3.get(Student.class, upId);
                    if (upStd != null) {
                        System.out.print("Enter New Dept: ");
                        String newDept = sc.next();
                        upStd.setDept(newDept);
                        s3.update(upStd);
                        tx3.commit();
                        System.out.println("Update Successful!");
                    } else {
                        System.out.println("ID does not exist.");
                    }
                    s3.close();
                    break;

                case 4: // DELETE
                    System.out.print("Enter Student ID to delete: ");
                    int delId = sc.nextInt();
                    
                    Session s4 = HibernateUtil.getSessionFactory().openSession();
                    Transaction tx4 = s4.beginTransaction();
                    
                    Student delStd = s4.get(Student.class, delId);
                    if (delStd != null) {
                        s4.delete(delStd);
                        tx4.commit();
                        System.out.println("Record Deleted!");
                    } else {
                        System.out.println("ID not found.");
                    }
                    s4.close();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
}